# LEGB rule
# (local, enclosing, global, build in)


