# modules and pip
# module - a python file that you can import into your current python file

import useful

print(useful.roll_dice(10))

# pip - a package manager
# used to install python modules

