
gender = True
height = False

if gender and height:
    print("you are a tall male")
elif gender and not height:
    print("you are a short male")
else:
    print("you are not tall or male  1:49")
