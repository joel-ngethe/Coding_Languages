# dictionaries = function that helps store info in key value pairs
# converting 3 month name to its full name jan -> january
monthConversions = {
    # this is a dictionary name
    # key : value
    "jan": "january",
    "feb": "february",
    "mar": "march",
    4: "april",
    "may": "may",
    "jun": "june",
    "jul": "july",
    "aug": "august",
    "sep": "sept",
    "oct": "oct",
    "nov": "november",
    "dec": "december",
}

# accessing a key or a value
print(monthConversions["nov"])
print(monthConversions.get("jan"))
print(monthConversions.get("luv", "not a valid key"))
print(monthConversions.get(4))