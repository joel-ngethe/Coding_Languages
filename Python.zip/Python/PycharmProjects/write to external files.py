# write to external files
# python read file
# open(file path, mode)
employee_file = open("employee.txt", "a")

employee_file.write("\ntoby - HR")

# w mode overwrites the whole doc

# create new file
employee1_file = open("employee1.txt", "w")
employee1_file.write("\nkelly - HR")


employee_file.close()