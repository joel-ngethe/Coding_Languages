# 2D lists & nested loops
# 2:45
# rows and columns

number_grid = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
    [0]
]

# print(number_grid[2][0])

for row in number_grid:
    for col in row:
        print(col)
