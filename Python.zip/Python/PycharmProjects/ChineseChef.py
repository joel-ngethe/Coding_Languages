from chef import Chef


class ChineseChef(Chef):

    def make_special(self):
        print("the chef makes orange chicken")

    def make_fried_rice(self):
        print("the chef makes fried rice")
