# Classes & Objects
# from <file> import <class>

from student import student

student1 = student("jim", "business", 3.1, False)
print(student1.name)