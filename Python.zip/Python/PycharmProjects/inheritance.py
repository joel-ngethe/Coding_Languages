# inheritance

from chef import Chef
from ChineseChef import ChineseChef

myChef = Chef()
myChef.make_chicken()


myChineseChef = ChineseChef()
myChineseChef.make_chicken()
myChineseChef.make_fried_rice()
myChineseChef.make_special()