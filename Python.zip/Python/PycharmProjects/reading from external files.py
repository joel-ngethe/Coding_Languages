# reading from external files
# python read file
# open(file path, mode) r - read, a- append, w - write
employee_file = open("employee.txt", "r")

# check if the file is readable
# print(employee_file.readable())
print(employee_file.readable())

# read the first line
print(employee_file.readline())

# output into a list
print(employee_file.readlines())

# loop
for employee in employee_file.readlines():
    print(employee)

employee_file.close()

