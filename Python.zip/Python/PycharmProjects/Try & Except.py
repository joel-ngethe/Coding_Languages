# Try & Except
# used in handling errors

try:
    # val = 10/0
    number = int(input("enter a number: "))
    print(number)
except ZeroDivisionError:
    print("number divided by zero!!")
except ValueError:
    print("invalid input!!")