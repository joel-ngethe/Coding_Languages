
#return function allows python to information from a function
#no code will execute after the return
def cube(num):
    return num*num*num


print(cube(3))

