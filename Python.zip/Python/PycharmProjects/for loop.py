# for loops

for letter in "tester":
    print(letter)

friends = ["alam", "jaohn", "joel"]
for guys in friends:
    print(guys)

# len() gets the length of an array
for inb in range(len(friends)):
    print(friends[inb])

for index in range(5, 10):
    print(index)