class Chef:

    def make_chicken(self):
        print("the chef makes chicken")

    def make_salad(self):
        print("the chef makes salad")

    def make_special(self):
        print("the chef makes bbq ribs")