﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {

            Chef chef = new Chef();
            chef.MakeChicken();
            chef.MakeSpecialDish();

            ItalianChef IChef = new ItalianChef();
            IChef.MakeChicken();
            IChef.MakePasta();
            IChef.MakeSpecialDish();

            Console.ReadLine();

        }
    }
}
