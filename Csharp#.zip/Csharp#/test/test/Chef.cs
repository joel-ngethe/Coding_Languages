﻿using System;
using System.Collections.Generic;
using System.Text;

namespace test
{
    class Chef
    {
        
        public void MakeChicken()
        {
            Console.WriteLine("the chef makes chicken");
        }
        public void MakeSalad()
        {
            Console.WriteLine("the chef makes salad");
        }

        //virtual means subclasses can overrite this
        public virtual void MakeSpecialDish()
        {
            Console.WriteLine("the chef makes bbr ribs");
        }


    }
}
