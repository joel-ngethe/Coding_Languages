﻿using System;
using System.Collections.Generic;
using System.Text;

namespace test
{
    class ItalianChef : Chef
    {
        public void MakePasta()
        {
            Console.WriteLine("the chef makes pasta");
        }
        public override void MakeSpecialDish()
        {
            Console.WriteLine("the chef makes sphagetti");
        }
    }
}
